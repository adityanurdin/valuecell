import{N as e,t,z as n}from"./jsx-runtime-C9msDtam.js";import"./react-dom-vScHQ3DX.js";import"./api-client-zb4YXT7n.js";import"./button-Diqbwkia.js";import"./createLucideIcon-sLk3weEK.js";import{d as r}from"./agent-B7J4qDXy.js";var i=n(t(),1),a=e(function(){return(0,i.jsx)(`div`,{className:`scroll-container`,children:(0,i.jsx)(r,{content:`| Symbol | Type | **Position/Quantity** | **Current/Avg** | P&L |
| :--- | :--- | :---: | :---: | :---: |
| BTC-USD | LONG | 0.0180 <br/> **$2,001.31** | $111,265.29<br>**$111,338.45** | 🟢 +$1.31 |
| ETH-USD | LONG | 0.4982 <br/> **$1,962.49** | $3,934.43<br>**$3,939.42** | 🟢 +$2.49 |
| BTC-USD | LONG | 0.0180 <br/> **$2,001.31** | $111,265.29<br>**$111,338.45** | 🟢 +$1.31 |
| ETH-USD | LONG | 0.4982 <br/> **$1,962.49** | $3,934.43<br>**$3,939.42** | 🟢 +$2.49 |
| BTC-USD | LONG | 0.0180 <br/> **$2,001.31** | $111,265.29<br>**$111,338.45** | 🟢 +$1.31 |
| ETH-USD | LONG | 0.4982 <br/> **$1,962.49** | $3,934.43<br>**$3,939.42** | 🟢 +$2.49 |
| BTC-USD | LONG | 0.0180 <br/> **$2,001.31** | $111,265.29<br>**$111,338.45** | 🟢 +$1.31 |
| ETH-USD | LONG | 0.4982 <br/> **$1,962.49** | $3,934.43<br>**$3,939.42** | 🟢 +$2.49 |`})})});export{a as default};